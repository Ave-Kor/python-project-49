### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ave-Kor/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ave-Kor/python-project-49/actions)

Maintainability [Badge](<a href="https://codeclimate.com/github/Ave-Kor/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/1f8e196b64828d03b536/maintainability" /></a>)

First game on [asciinema.org](https://asciinema.org/a/uqn7N248vykyRv2KobCdbDOfT)

Second game on [asciinema.org](https://asciinema.org/a/QVFOG4vnlc0JtT5zv3EI6NDDN)

Third game on [asciinema.org](https://asciinema.org/a/KgwwZtEaXG2M0atbUix9qKgpw)
